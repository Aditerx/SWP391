import React, { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { SCMSProvider } from './context/SCMSContext'
import './index.css'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <SCMSProvider>
        <App />
      </SCMSProvider>
    </BrowserRouter>
  </StrictMode>,
)

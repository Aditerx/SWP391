import React, { useState } from 'react';
import { useSCMS } from '../../context/SCMSContext';
import { formatCurrency } from '../../locales/translations';
import { Package, CheckCircle2, Shield, Layers, Sparkles, Plus, Clock, Users } from 'lucide-react';

export function PackageManagement() {
  const { packages, members, t, language } = useSCMS();

  // Quick stats
  const totalPackages = packages.length;
  const activePackages = packages.filter(p => p.status === 'active').length;
  const enrolledMembers = members.filter(m => m.currentPackageId).length;

  return (
    <div className="space-y-6">
      {/* 3-Card Quick KPI Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-stone-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-500 text-xs mb-1 font-medium">
            <span>{language === 'vi' ? 'Tổng số gói tập' : 'Total Packages'}</span>
            <Package className="w-4 h-4 text-stone-400" />
          </div>
          <div className="text-2xl font-bold text-stone-900 tabular-nums">{totalPackages}</div>
          <p className="text-[11px] text-stone-500 mt-1">
            {language === 'vi' ? `${activePackages} gói đang mở đăng ký` : `${activePackages} packages available`}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-500 text-xs mb-1 font-medium">
            <span>{language === 'vi' ? 'Hội viên có gói' : 'Enrolled Members'}</span>
            <Users className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-2xl font-bold text-orange-600 tabular-nums">{enrolledMembers}</div>
          <p className="text-[11px] text-stone-500 mt-1">
            {language === 'vi' ? 'Thành viên đã kích hoạt quyền lợi' : 'Members with active package'}
          </p>
        </div>

        <div className="bg-white border border-stone-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between text-stone-500 text-xs mb-1 font-medium">
            <span>{language === 'vi' ? 'Chính sách gia hạn' : 'Grace Period Policy'}</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-600 tabular-nums">72h</div>
          <p className="text-[11px] text-stone-500 mt-1">
            {language === 'vi' ? 'Thời gian cho phép gia hạn sau khi hết hạn gói' : 'Standard grace period on expiry'}
          </p>
        </div>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white border border-stone-200 p-4 rounded-lg shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-stone-100 text-stone-800 rounded border border-stone-200">
            <Package className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-stone-900 tracking-tight">{t('packages')}</h2>
            <p className="text-xs text-stone-500">
              {language === 'vi' ? 'Danh sách gói dịch vụ, mức giá, thời hạn và quyền lợi kế thừa theo hạng' : 'Service packages, prices, durations and inherited tier benefits'}
            </p>
          </div>
        </div>

        <button
          onClick={() => alert(language === 'vi' ? 'Tính năng tạo gói mới đang được chuẩn bị!' : 'Create package feature coming soon!')}
          className="px-3.5 py-1.5 bg-stone-900 hover:bg-orange-600 text-white rounded text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors whitespace-nowrap"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{language === 'vi' ? 'Tạo gói mới' : 'Create Package'}</span>
        </button>
      </div>

      {/* Package Tier Comparison Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {packages.map(pkg => (
          <div
            key={pkg.id}
            className={`bg-white border rounded-lg p-6 flex flex-col justify-between relative shadow-2xs transition-all ${
              pkg.tier === 3
                ? 'border-amber-400 ring-2 ring-amber-400/30'
                : 'border-stone-200 hover:border-orange-500/50'
            }`}
          >
            {pkg.tier === 3 && (
              <div className="absolute -top-3 right-4 px-2.5 py-0.5 bg-gradient-to-r from-amber-500 to-orange-500 text-stone-950 font-extrabold text-[10px] uppercase rounded shadow-xs flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>{language === 'vi' ? 'ĐẶC QUYỀN CAO CẤP' : 'PREMIUM BENEFITS'}</span>
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                  pkg.tier === 3
                    ? 'bg-amber-50 text-amber-900 border-amber-300'
                    : 'bg-stone-100 text-stone-700 border-stone-200'
                }`}>
                  TIER {pkg.tier}
                </span>
                <span className="text-xs text-orange-600 font-bold">
                  {pkg.durationMonths} {language === 'vi' ? 'tháng' : (pkg.durationMonths === 1 ? 'month' : 'months')}
                </span>
              </div>

              <h3 className="text-base font-bold text-stone-900 mb-1">
                {language === 'vi' ? pkg.nameVi : pkg.name}
              </h3>
              <p className="text-xs text-stone-600 mb-4 min-h-[32px]">
                {language === 'vi' ? pkg.descriptionVi : pkg.description}
              </p>

              <div className="mb-6 p-3 bg-stone-50 rounded border border-stone-200">
                <div className="text-[10px] text-stone-500 uppercase font-bold whitespace-nowrap">
                  {language === 'vi' ? 'Mức giá niêm yết' : 'Standard Price'}
                </div>
                <div className="text-xl font-bold text-stone-900 tabular-nums mt-0.5">
                  {formatCurrency(pkg.price, language)}
                </div>
              </div>

              {/* Benefits checklist */}
              <div className="space-y-2.5 mb-6">
                <div className="text-[11px] font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-orange-600" />
                  <span>{language === 'vi' ? 'Quyền lợi bao gồm:' : 'Included benefits:'}</span>
                </div>
                {(language === 'vi' ? pkg.benefitsVi : pkg.benefits).map((b, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-stone-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Inheritance Banner */}
            {pkg.tier > 1 ? (
              <div className="pt-3 border-t border-stone-200 text-[11px] text-stone-700 font-medium flex items-center gap-1.5 bg-stone-50 -mx-6 -mb-6 p-3 rounded-b-lg">
                <Shield className="w-3.5 h-3.5 text-orange-600 shrink-0" />
                <span>
                  {language === 'vi'
                    ? `Bao gồm toàn bộ quyền lợi của gói Tier ${pkg.tier - 1}`
                    : `Includes all Tier ${pkg.tier - 1} benefits`}
                </span>
              </div>
            ) : (
              <div className="pt-3 border-t border-stone-200 text-[11px] text-stone-500 font-medium flex items-center gap-1.5 bg-stone-50 -mx-6 -mb-6 p-3 rounded-b-lg">
                <Shield className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                <span>{language === 'vi' ? 'Gói nền tảng khởi đầu' : 'Foundation starter plan'}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
